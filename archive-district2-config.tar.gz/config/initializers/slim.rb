# Forcing Slim to render minified html
Slim::Engine.set_options pretty: false
